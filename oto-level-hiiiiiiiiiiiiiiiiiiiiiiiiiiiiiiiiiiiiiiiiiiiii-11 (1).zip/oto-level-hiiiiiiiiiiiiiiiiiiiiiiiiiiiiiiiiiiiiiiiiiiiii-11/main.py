import os; os.system("python3 webserver.py & >/dev/null")
import requests
import time



playload = {

    'content' : 'test'


}

headerst = {

    'authorization': 'MTM4MzQ4NTY4MzQxNDMzOTU4NA.Gc2iBG.w1jM-BBPpFr1Iyr0rjZk_vVmNvOc1tjUvoVSIY' # < < توكن الحساب الاول

}

headerst1 = {

    'authorization': 'ODMwOTM0MTAzODQ2NDIwNDgw.GhMYG_.IghS7Z_QUTEmUqFApNzbSlyje97XCM91Y3UqIU' # < < توكن الحساب الثاني

}
headerst2 = {

    'authorization': '' # < < توكن الحساب الثالث

}

channel = '1383486794942775439' # < < ايدي الروم

url = f'https://discord.com/api/v8/channels/{channel}/messages'


while True:
    requests.post(url, data=playload, headers=headerst, )
    requests.post(url, data=playload, headers=headerst1, )
    requests.post(url, data=playload, headers=headerst2, )
    time.sleep(2) # < < كم رساله في الثانيه


